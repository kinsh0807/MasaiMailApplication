package com.masai.app.mail.Service;

import com.masai.app.mail.entity.Email;
import com.masai.app.mail.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface Service_User {

    User registerUser(User user);
    User loginUser(String email,String mobileNumber );
    List<Email> getAllMails();
    List<Email> getStarredMails();
    User updateUser(User user);
}
