package com.masai.app.mail.exceptions;

public class InvalidException extends RuntimeException{

	public InvalidException() {}
	
	public InvalidException(String msg) {
		super(msg);
	}
}
