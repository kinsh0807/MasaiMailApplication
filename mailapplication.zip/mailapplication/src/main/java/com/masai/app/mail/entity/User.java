package com.masai.app.mail.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data

public class User {


    @Id
    @GeneratedValue
    private String u_Email;
    private String firstName;
    private String lastName;
    private String mobileNumber;
    private LocalDate dateOfBirth;

}
