package com.masai.app.mail.controller;



import com.masai.app.mail.Service.Service_Email;
import com.masai.app.mail.Service.Service_User;
import com.masai.app.mail.entity.Email;
import com.masai.app.mail.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/masaimail")
public class MyController {

    @Autowired
    Service_User userservice;
    @Autowired
    Service_Email emailservice;


    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        User registeredUser = userservice.registerUser(user);
        return new ResponseEntity<User>(registeredUser, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        User registeredUser = userservice.registerUser(user);
        return new ResponseEntity<User>(login User, HttpStatus.CREATED);
    }

    @GetMapping("/mail")
    public ResponseEntity<?> getMail() {
        List<Email> emails = userservice.getAllMails();
        return ResponseEntity.ok(emails);
    }

    @GetMapping("/starred")
    public ResponseEntity<?> getStarredMail() {
        List<Email> emails = userservice.getStarredMails();
        return ResponseEntity.ok(emails);
    }

    @PutMapping("/user")
    public ResponseEntity<?> updateUser(@RequestBody User user) {
        User updateUser = userservice.updateUser(user);
        return ResponseEntity.ok(updateUser);
    }

    @PostMapping("/mail")
    public ResponseEntity<?> postMail(@RequestBody Email email) {
        Email service = emailservice.sendMail(email);
        return ResponseEntity.ok(service);
    }

    @PostMapping("/starred/{id}")
    public ResponseEntity<?> starEmail(@PathVariable int id) {
        Email starMail = emailservice.starMail(id);
        return ResponseEntity.ok(starMail);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteEmail(@PathVariable int id) {
        boolean deletedEmail = emailservice.deleteMail(id);
        return ResponseEntity.ok(deletedEmail);
    }
}


