package com.masai.app.mail.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data

public class Email {

    @Id
    private int id;
    private String subject;
    private String message;
    private String cc_id;
    private String starredMessage;

    @ManyToOne
    private User user;
}
