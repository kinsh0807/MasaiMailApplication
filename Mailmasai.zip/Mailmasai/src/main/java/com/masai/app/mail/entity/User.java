package com.masai.app.mail.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;
import java.util.List;


@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data

public class User {


    @Id
    @Column(unique = true)
    private String email;
    @Pattern(regexp="^[A-Z][a-z]*")
    private String firstName;
    @Pattern(regexp="^[A-Z][a-z]*")
    private String lastName;
    @Size(min=10,max=20)
    private String mobileNumber;
    @Past(message="{dateOfBirth.invalid}")
    private LocalDate dateOfBirth;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Email> emailservice;

}
