package com.masai.app.mail.Repository;

import com.masai.app.mail.entity.Email;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface Email_Repo extends JpaRepository<Email,Integer> {

    List<Email> findByStarredMessage(Boolean starredMessage);
}
