package com.masai.app.mail.Service;

import com.masai.app.mail.entity.Email;
import org.springframework.stereotype.Service;

@Service
public interface Service_Email {

    Email sendMail(Email email);
    Email starMail(int id);
    Boolean deleteMail(int id);
}

